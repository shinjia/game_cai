var a = 3;
var b = 7;
var obj_q, obj_a;


function show_question(op)
{
  var str = '';

  switch(op)
  {
    case 1:
      a = Math.floor(Math.random()*90) + 10;
      b = Math.floor(Math.random()*90) + 1;
      str = a + ' + ' + b;

      obj_q = document.getElementById('my_question1');
      obj_a = document.getElementById('my_answer1');
      break;

    case 2:
      a = Math.floor(Math.random()*90) + 10;
      b = Math.floor(Math.random()*a) + 1;
      str = a + ' - ' + b;

      obj_q = document.getElementById('my_question2');
      obj_a = document.getElementById('my_answer2');
      break;

    case 3:
      a = Math.floor(Math.random()*9) + 1;
      b = Math.floor(Math.random()*9) + 1;
      str = a + ' x ' + b;

      obj_q = document.getElementById('my_question3');
      obj_a = document.getElementById('my_answer3');
      break;

    case 4:
      var c = Math.floor(Math.random()*8) + 2;
      b = Math.floor(Math.random()*8) + 2;
      a = c * b;
      str = a + ' / ' + b;

      obj_q = document.getElementById('my_question4');
      obj_a = document.getElementById('my_answer4');
      break;
  }

  obj_q.innerHTML = str;
  obj_a.style.display = 'none';
}



function show_answer(op)
{
  var ans;
  var str = '';

  switch(op)
  {
    case 1:
      ans = a + b;
      break;

    case 2:
      ans = a - b;
      break;

    case 3:
      ans = a * b;
      break;

    case 4:
      ans = a / b;
      break;
  }
  
  str = '答案是 ' + ans;

  obj_a.innerHTML = str; 
  obj_a.style.display = 'block';
}


